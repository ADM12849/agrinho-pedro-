function setup() {
  createCanvas(800, 400);
  noLoop();
}

function draw() {
  // Céu
  background(135, 206, 235);

  // Sol
  fill(255, 223, 0);
  ellipse(700, 80, 100, 100);

  // Grama
  fill(34, 139, 34);
  rect(0, 300, width, 100);

  // Árvores
  drawTree(100, 250);
  drawTree(200, 260);
  drawTree(300, 240);

  // Horta (representada por canteiros)
  drawGarden(450, 320);
  drawGarden(520, 320);
  drawGarden(590, 320);

  // Trator (representação simples)
  drawTractor(150, 330);

  // Texto
  fill(255);
  rect(50, 20, 500, 60, 10);
  fill(0);
  textSize(16);
  text("Agrinho 2025 – Cultivar Saberes, Colher Futuro", 60, 40);
  text("🌱 Educação, campo e sustentabilidade caminhando juntos!", 60, 60);
}

function drawTree(x, y) {
  // Tronco
  fill(101, 67, 33);
  rect(x, y, 20, 60);
  // Copa
  fill(34, 139, 34);
  ellipse(x + 10, y, 60, 60);
}

function drawGarden(x, y) {
  fill(139, 69, 19);
  rect(x, y, 50, 20);
  fill(0, 200, 0);
  ellipse(x + 10, y, 10, 10);
  ellipse(x + 25, y - 5, 10, 10);
  ellipse(x + 40, y, 10, 10);
}

function drawTractor(x, y) {
  // Corpo
  fill(255, 0, 0);
  rect(x, y - 20, 60, 20);
  rect(x + 10, y - 40, 30, 20);
  
  // Rodas
  fill(0);
  ellipse(x + 10, y, 20, 20);
  ellipse(x + 50, y, 30, 30);
}
